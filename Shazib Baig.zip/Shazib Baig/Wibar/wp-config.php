<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'wibar' );

/** MySQL database username */
define( 'DB_USER', 'root' );

/** MySQL database password */
define( 'DB_PASSWORD', '' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'G#E$5]D{!KR3rupu:p?)YXb$eOdp6BZ}7HR>shNXV(BIZzo)N9SXk109/GJFju44' );
define( 'SECURE_AUTH_KEY',  'EftG=!4Cuv4,`MQQj_XR$uTk.$nk)O$]<XH-$5l(5Kzrc/HV8-0#Pna1H&&V}J$?' );
define( 'LOGGED_IN_KEY',    'k/.mvc:h[V<iZ?1q=TF(P~U2t~9m!xD;][{o?wB}6:T?8Tf$[d%w{wihNQ~,w37V' );
define( 'NONCE_KEY',        'LCE{][;DeK!uW1)W5vecCA^N}%zuPTO#7iiY+JKDD}j3oYRn=lMj4aZGbQFg@%o^' );
define( 'AUTH_SALT',        '+#Cmq~K04,h3SYP4;jD5u>N65&s.FV2XLVI;z]#F.055]-kAg6$4@Hy6co`[el9Y' );
define( 'SECURE_AUTH_SALT', '.cVd2uGXRpn9J?_-> IiV1Oo<YvOOQjsjfmz>o_ly&k9t*44LI5|(FbsX},!!TUh' );
define( 'LOGGED_IN_SALT',   'Z}2R(nnKb}Mm0pb:<iA^N53+A]$%bx/XIFumP$vqX;(bs=e<xmQ[6J7>hVB9MnLz' );
define( 'NONCE_SALT',       'Hm?>>lgBht7MBNWK6:-k,&1CJ?#<c,?+2K:fSGxi@|?a(xQ9.q:A!ARyht<~zN+Q' );

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
